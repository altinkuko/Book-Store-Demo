package com.example.weblibraryapp.errors;

public class ErrorMessages {
    public final static String ID_NOT_FOUND_EXCEPTION = "Id not found";
}
